FORGOTTEN ARCHIVE

Backup recovered from an old workstation.

Most files are routine.
One artifact may be worth closer inspection.
